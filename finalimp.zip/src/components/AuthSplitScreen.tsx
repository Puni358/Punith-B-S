import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Eye, EyeOff, ArrowRight, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface AuthSplitScreenProps {
  initialMode: 'login' | 'signup';
}

export const AuthSplitScreen: React.FC<AuthSplitScreenProps> = ({ initialMode }) => {
  const { login, signup, loginWithGoogle } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [isSignUp, setIsSignUp] = useState(initialMode === 'signup');
  const [showPassword, setShowPassword] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(true);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [mounted, setMounted] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);

  // Form input states
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Async feedback states
  const [submitting, setSubmitting] = useState(false);
  const [googleSubmitting, setGoogleSubmitting] = useState(false);
  const [appleSubmitting, setAppleSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const slides = [
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UVCE3-scNKiop2cPHp4ljvWmMHsUDRTHwzXR.jpg",
      alt: "UVCE heritage building courtyard framed by large rain trees",
      title: "A Century of Excellence",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UVCE4-r4pWTZKNqNYKRWAGwwbRLEQuMvOEcO.jpg",
      alt: "UVCE main building lit up with blue lights at night",
      title: "Lighting Up Tradition",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UVCE1-FUzQh5CaZP65Ls5yYOMEGxpHNN1wOp.jpg",
      alt: "UVCE building glowing with colorful lights on Alumni Day",
      title: "Celebrating Our Legacy",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UVCE5-Z3BFwh6qkJqFcQGt7O2osuFLyZrRxE.jpg",
      alt: "Garlanded entrance archway of UVCE decorated with flowers",
      title: "Honoring Our Roots",
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UVCE_Gallery2-wNCzhowfSNxCSk3W9CJ0agovKtUBT7.jpg",
      alt: "Garlanded statue of Sir M. Visvesvaraya with floor rangoli at UVCE",
      title: "The Visionary Behind It All",
    },
  ];

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    setIsSignUp(initialMode === 'signup');
    setError(null);
    setSuccessMsg(null);
  }, [initialMode]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [slides.length]);

  const handleModeSwitch = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      const nextModeIsSignUp = !isSignUp;
      setIsSignUp(nextModeIsSignUp);
      setError(null);
      setSuccessMsg(null);
      navigate(nextModeIsSignUp ? '/signup' : '/login', { replace: true });
      setTimeout(() => {
        setIsTransitioning(false);
      }, 50);
    }, 150);
  };

  const from = (location.state as any)?.from?.pathname || '/browse';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!email.trim() || !password.trim()) {
      setError('Please fill in all required fields.');
      return;
    }

    if (isSignUp) {
      if (!agreedToTerms) {
        setError('Please agree to the Terms & Conditions to proceed.');
        return;
      }

      setSubmitting(true);
      try {
        const fullName = `${firstName} ${lastName}`.trim() || 'Student User';
        await signup(fullName, email, password);
        setSuccessMsg('Account created successfully! Redirecting...');
        setTimeout(() => {
          navigate(from, { replace: true });
        }, 500);
      } catch (err: any) {
        setError(err.message || 'Failed to create account.');
      } finally {
        setSubmitting(false);
      }
    } else {
      setSubmitting(true);
      try {
        await login(email, password);
        setSuccessMsg('Welcome back! Redirecting...');
        setTimeout(() => {
          navigate(from, { replace: true });
        }, 500);
      } catch (err: any) {
        setError(err.message || 'Login failed. Please check your credentials.');
      } finally {
        setSubmitting(false);
      }
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setSuccessMsg(null);
    setGoogleSubmitting(true);
    try {
      await loginWithGoogle();
      setSuccessMsg('Signed in with Google! Redirecting...');
      setTimeout(() => {
        navigate(from, { replace: true });
      }, 500);
    } catch (err: any) {
      setError(err.message || 'Google sign-in failed.');
    } finally {
      setGoogleSubmitting(false);
    }
  };

  const handleAppleSignIn = async () => {
    setError(null);
    setSuccessMsg(null);
    setAppleSubmitting(true);
    try {
      await loginWithGoogle();
      setSuccessMsg('Signed in with Apple! Redirecting...');
      setTimeout(() => {
        navigate(from, { replace: true });
      }, 500);
    } catch (err: any) {
      setError(err.message || 'Apple sign-in failed.');
    } finally {
      setAppleSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#1a1a24] flex items-center justify-center p-4">
      <div 
        className={`w-full max-w-4xl bg-[#12121a] rounded-3xl overflow-hidden flex flex-col lg:flex-row shadow-2xl shadow-black/50 transition-all duration-700 ease-out ${
          mounted ? "opacity-100 scale-100" : "opacity-0 scale-95"
        }`}
      >
        {/* Left Panel */}
        <div className="lg:w-[45%] bg-[#0f0f16] p-5 flex flex-col">
          {/* Header */}
          <div 
            className={`flex items-center justify-between mb-4 transition-all duration-500 delay-200 ${
              mounted ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"
            }`}
          >
            <div className="text-white text-xl font-bold tracking-wider">
              <span className="bg-gradient-to-r from-purple-400 to-purple-600 bg-clip-text text-transparent">NOVA</span>
            </div>
            <button 
              type="button"
              onClick={() => navigate('/browse')}
              className="flex items-center gap-1.5 bg-[#1f1f2a]/80 backdrop-blur-sm hover:bg-[#2a2a38] text-white/90 text-xs px-3 py-1.5 rounded-full transition-all duration-300 border border-white/5 hover:border-white/10 cursor-pointer"
            >
              Back to website
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {/* Image Container */}
          <div 
            className={`flex-1 relative rounded-2xl overflow-hidden min-h-[260px] transition-all duration-700 delay-300 ${
              mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            {slides.map((slide, index) => (
              <img
                key={slide.src}
                src={slide.src}
                alt={slide.alt}
                className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ease-in-out ${
                  currentSlide === index ? "opacity-100" : "opacity-0"
                }`}
              />
            ))}
            <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f16] via-[#0f0f16]/20 to-transparent" />
            
            {/* Text Overlay */}
            <div 
              className={`absolute bottom-6 left-0 right-0 text-center px-4 transition-all duration-500 delay-500 ${
                mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              <h2 key={currentSlide} className="text-white text-xl font-semibold leading-tight tracking-tight animate-in fade-in slide-in-from-bottom-2 duration-700">
                {slides[currentSlide].title}
              </h2>
            </div>
          </div>

          {/* Carousel Dots */}
          <div 
            className={`flex items-center justify-center gap-1.5 mt-4 transition-all duration-500 delay-[600ms] ${
              mounted ? "opacity-100" : "opacity-0"
            }`}
          >
            {slides.map((_, index) => (
              <button
                key={index}
                type="button"
                aria-label={`Go to slide ${index + 1}`}
                onClick={() => setCurrentSlide(index)}
                className={`h-0.5 rounded-full transition-all duration-300 cursor-pointer ${
                  currentSlide === index
                    ? "w-6 bg-white"
                    : "w-3 bg-white/20 hover:bg-white/40"
                }`}
              />
            ))}
          </div>
        </div>

        {/* Right Panel - Form */}
        <div className="lg:w-[55%] p-6 lg:p-8 flex flex-col justify-center">
          <div className={`transition-all duration-300 ease-out ${isTransitioning ? "opacity-0 translate-y-2" : "opacity-100 translate-y-0"}`}>
            <h1 
              className={`text-white text-2xl lg:text-3xl font-bold mb-1 tracking-tight transition-all duration-500 delay-300 ${
                mounted ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"
              }`}
            >
              {isSignUp ? "Create an account" : "Welcome back"}
            </h1>
            <p 
              className={`text-white/40 text-sm mb-6 transition-all duration-500 delay-[350ms] ${
                mounted ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"
              }`}
            >
              {isSignUp ? "Already have an account? " : "Don't have an account? "}
              <button
                type="button"
                onClick={handleModeSwitch}
                className="text-white/80 underline underline-offset-2 hover:text-purple-400 transition-colors duration-300 cursor-pointer"
              >
                {isSignUp ? "Log in" : "Sign up"}
              </button>
            </p>
          </div>

          {/* Error & Success Feedback Alerts */}
          {error && (
            <div className="mb-4 p-3 bg-red-950/60 border border-red-500/30 rounded-xl text-red-200 text-xs font-medium flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}
          {successMsg && (
            <div className="mb-4 p-3 bg-emerald-950/60 border border-emerald-500/30 rounded-xl text-emerald-200 text-xs font-medium flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3">
            {/* Name Fields - Animated Height */}
            <div 
              className={`grid transition-all duration-400 ease-out overflow-hidden ${
                isSignUp ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
              }`}
            >
              <div className="overflow-hidden">
                <div 
                  className={`grid grid-cols-2 gap-3 pb-3 transition-all duration-500 delay-[400ms] ${
                    mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
                  }`}
                >
                  <input
                    type="text"
                    placeholder="First name"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="w-full bg-[#1a1a26] border border-white/5 rounded-xl px-4 py-2.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-purple-500/50 focus:ring-1 focus:ring-purple-500/20 transition-all duration-300"
                  />
                  <input
                    type="text"
                    placeholder="Last name"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    className="w-full bg-[#1a1a26] border border-white/5 rounded-xl px-4 py-2.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-purple-500/50 focus:ring-1 focus:ring-purple-500/20 transition-all duration-300"
                  />
                </div>
              </div>
            </div>

            <div
              className={`transition-all duration-500 delay-[450ms] ${
                mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              <input
                type="email"
                placeholder="Email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#1a1a26] border border-white/5 rounded-xl px-4 py-2.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-purple-500/50 focus:ring-1 focus:ring-purple-500/20 transition-all duration-300"
              />
            </div>

            <div 
              className={`relative transition-all duration-500 delay-[500ms] ${
                mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#1a1a26] border border-white/5 rounded-xl px-4 py-2.5 pr-10 text-sm text-white placeholder-white/30 focus:outline-none focus:border-purple-500/50 focus:ring-1 focus:ring-purple-500/20 transition-all duration-300"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors duration-300 cursor-pointer"
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>

            {/* Terms Checkbox - Animated */}
            <div 
              className={`grid transition-all duration-400 ease-out overflow-hidden ${
                isSignUp ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
              }`}
            >
              <div className="overflow-hidden">
                <label 
                  className={`flex items-center gap-2.5 cursor-pointer py-1 transition-all duration-500 delay-[550ms] ${
                    mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
                  }`}
                >
                  <div className="relative">
                    <input
                      type="checkbox"
                      checked={agreedToTerms}
                      onChange={(e) => setAgreedToTerms(e.target.checked)}
                      className="sr-only"
                    />
                    <div
                      className={`w-4 h-4 rounded flex items-center justify-center transition-all duration-300 ${
                        agreedToTerms
                          ? "bg-purple-500 shadow-lg shadow-purple-500/30"
                          : "border border-white/20 bg-transparent"
                      }`}
                    >
                      <svg
                        className={`w-2.5 h-2.5 text-white transition-all duration-300 ${
                          agreedToTerms ? "opacity-100 scale-100" : "opacity-0 scale-50"
                        }`}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={3}
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                    </div>
                  </div>
                  <span className="text-white/40 text-xs">
                    I agree to the{" "}
                    <a href="#" onClick={(e) => e.preventDefault()} className="text-purple-400 underline underline-offset-2 hover:text-purple-300 transition-colors duration-300">
                      Terms & Conditions
                    </a>
                  </span>
                </label>
              </div>
            </div>

            <div
              className={`transition-all duration-500 delay-[600ms] ${
                mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              <button
                type="submit"
                disabled={submitting}
                className="w-full bg-purple-500 hover:bg-purple-400 text-white font-medium py-2.5 rounded-xl transition-all duration-300 text-sm shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 hover:-translate-y-0.5 active:translate-y-0 active:shadow-purple-500/20 cursor-pointer flex items-center justify-center gap-2"
              >
                {submitting ? (
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                ) : (
                  <span className={`inline-block transition-all duration-300 ${isTransitioning ? "opacity-0 scale-95" : "opacity-100 scale-100"}`}>
                    {isSignUp ? "Create account" : "Sign in"}
                  </span>
                )}
              </button>
            </div>
          </form>

          {/* Divider */}
          <div 
            className={`flex items-center gap-3 my-5 transition-all duration-500 delay-[650ms] ${
              mounted ? "opacity-100" : "opacity-0"
            }`}
          >
            <div className="flex-1 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
            <span className={`text-white/30 text-xs transition-all duration-300 ${isTransitioning ? "opacity-0" : "opacity-100"}`}>
              {isSignUp ? "Or register with" : "Or sign in with"}
            </span>
            <div className="flex-1 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
          </div>

          {/* Social Buttons */}
          <div 
            className={`grid grid-cols-2 gap-3 transition-all duration-500 delay-700 ${
              mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            }`}
          >
            <button 
              type="button"
              onClick={handleGoogleSignIn}
              disabled={googleSubmitting}
              className="flex items-center justify-center gap-2 bg-[#1a1a26] border border-white/5 hover:border-white/20 hover:bg-[#1f1f2a] text-white text-sm py-2.5 rounded-xl transition-all duration-300 group hover:scale-[1.02] active:scale-100 cursor-pointer"
            >
              {googleSubmitting ? (
                <Loader2 className="w-4 h-4 animate-spin text-white" />
              ) : (
                <>
                  <svg className="w-4 h-4 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                  </svg>
                  <span className="text-white/80 group-hover:text-white transition-colors duration-300">Google</span>
                </>
              )}
            </button>
            <button 
              type="button"
              onClick={handleAppleSignIn}
              disabled={appleSubmitting}
              className="flex items-center justify-center gap-2 bg-[#1a1a26] border border-white/5 hover:border-white/20 hover:bg-[#1f1f2a] text-white text-sm py-2.5 rounded-xl transition-all duration-300 group hover:scale-[1.02] active:scale-100 cursor-pointer"
            >
              {appleSubmitting ? (
                <Loader2 className="w-4 h-4 animate-spin text-white" />
              ) : (
                <>
                  <svg className="w-4 h-4 text-white/80 group-hover:text-white transition-all duration-300 group-hover:scale-110" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" />
                  </svg>
                  <span className="text-white/80 group-hover:text-white transition-colors duration-300">Apple</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
